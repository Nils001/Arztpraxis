
public class Familie extends Mensch
{
    public Familie()
    {
        super(6);
  
    }
}
