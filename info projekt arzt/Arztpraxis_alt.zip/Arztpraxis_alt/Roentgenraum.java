
public class Roentgenraum extends Raum
{
    public Roentgenraum()
    {
    }
}
